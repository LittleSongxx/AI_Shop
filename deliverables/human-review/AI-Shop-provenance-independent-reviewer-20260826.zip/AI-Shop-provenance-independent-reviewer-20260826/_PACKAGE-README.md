# AI-Shop-provenance-independent-reviewer-20260826

仅供来源独立复核者；不得接触历史标签、旧评审、v2.1 新政策或模型输出。

只修改分配给你的 JSONL 中允许编辑的字段；不要修改 manifest。完成后保留文件名并回传 JSONL 与同名 manifest。
