# AI-Shop-label-policy-reviewer-b-20260826

仅供标签政策 reviewer-b；在 seal 前不得查看 reviewer-a、旧 gold、任何模型输出或仲裁上下文。

只修改分配给你的 JSONL 中允许编辑的字段；不要修改 manifest。完成后保留文件名并回传 JSONL 与同名 manifest。
