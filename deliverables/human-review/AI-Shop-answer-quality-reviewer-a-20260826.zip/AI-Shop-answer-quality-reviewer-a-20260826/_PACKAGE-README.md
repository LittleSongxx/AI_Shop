# AI-Shop-answer-quality-reviewer-a-20260826

仅供答案质量 reviewer-a；不得查看 reviewer-b、旧答案标签、模型自评或仲裁上下文。

只修改分配给你的 JSONL 中允许编辑的字段；不要修改 manifest。完成后保留文件名并回传 JSONL 与同名 manifest。
