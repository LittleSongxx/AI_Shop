# AI-Shop-human-review-coordinator-20260826

协调人母包：同时含 A/B，禁止原样发给单个 reviewer。

只修改分配给你的 JSONL 中允许编辑的字段；不要修改 manifest。完成后保留文件名并回传 JSONL 与同名 manifest。
